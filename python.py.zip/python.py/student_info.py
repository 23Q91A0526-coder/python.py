name = input("Enter Student Name: ")
roll = input("Enter Roll Number: ")
branch = input("Enter Branch: ")
marks = float(input("Enter Marks: "))

percentage = (marks / 100) * 100

print("\n------ Student Information ------")
print("Name:", name)
print("Roll Number:", roll)
print("Branch:", branch)
print("Marks:", marks)
print("Percentage:", percentage, "%")