# Variables of different data types

student_name = "Manohar"
student_age = 21
cgpa = 8.2
is_student = True

print("Name:", student_name)
print("Data Type:", type(student_name))

print("Age:", student_age)
print("Data Type:", type(student_age))

print("CGPA:", cgpa)
print("Data Type:", type(cgpa))

print("Student:", is_student)
print("Data Type:", type(is_student))